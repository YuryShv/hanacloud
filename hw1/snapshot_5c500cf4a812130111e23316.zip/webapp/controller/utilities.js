sap.ui.define([
	"./utilities"
], function() {
	"use strict";

	// class providing static utility methods to retrieve entity default values.

	return {
		getDefaultValuesForPage3: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"Name": "",
				"Category": "",
				"Price": 0,
				"Currency": "",
				"MainCategory": "",
				"Length": 0,
				"LengthUnit": "",
				"Width": 0,
				"WidthUnit": "",
				"Height": 0,
				"HeightUnit": "",
				"Weight": 0,
				"WeightUnit": "",
				"ProductImage": "",
				"StockLevel": "",
				"StockLevelCC": "",
				"PriceRange": "",
				"___FK_7bf081fc826214da0d9259f8": "",
				"___FK_dd66778c188db89f0d9259f8": ""
			};
		}
	};
});
